# S.A. Towing & Recovery Website

## Start Website
1. Run:
npm install

2. Then:
npm start

## Deploy
Upload this project to GitHub and import into Vercel.
