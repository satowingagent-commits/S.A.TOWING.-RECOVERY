export default function App() {
  return (
    <div className="app">
      <header className="hero">
        <h1>S.A. Towing & Recovery</h1>
        <p>Professional Recovery & Repossession Services</p>

        <div className="buttons">
          <a href="tel:2104348699">Call Dispatch</a>
          <a href="#appointments">Schedule Appointment</a>
        </div>
      </header>

      <section className="section">
        <h2>Vehicle VIN Lookup</h2>
        <input placeholder="Enter Last 6 Of VIN" />
        <button>Search Vehicle</button>
      </section>

      <section className="section" id="appointments">
        <h2>Book Appointment</h2>
        <div className="card-grid">
          <div className="card">
            <h3>Redemption Pickup</h3>
            <input placeholder="Full Name" />
            <input placeholder="VIN" />
            <button>Schedule</button>
          </div>

          <div className="card">
            <h3>Transport Pickup</h3>
            <input placeholder="Transport Company" />
            <input placeholder="VIN" />
            <button>Schedule</button>
          </div>
        </div>
      </section>

      <section className="section">
        <h2>24/7 AI Support Assistant</h2>
        <div className="chatbox">
          <p>
            Ask questions about vehicle releases, transport approvals,
            redemption requirements, fees, and appointments.
          </p>
          <input placeholder="Ask a question..." />
        </div>
      </section>

      <footer className="footer">
        <h3>Contact Information</h3>
        <p>Phone: 210-434-8699</p>
        <p>Email: satowing@sbcglobal.net</p>
        <p>Hours: Monday-Friday 9AM-3PM</p>
      </footer>
    </div>
  );
}
